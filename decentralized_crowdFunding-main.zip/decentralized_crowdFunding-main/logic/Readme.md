# Logic files for logic with intenal Token

### Note - Replace SampleLogic with actual Module name in coco.nut, .coco file
