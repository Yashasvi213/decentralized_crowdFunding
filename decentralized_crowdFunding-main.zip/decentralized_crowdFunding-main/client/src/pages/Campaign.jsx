const Campaign = () => {
  return "For the individual Campaign";
};

export default Campaign;
