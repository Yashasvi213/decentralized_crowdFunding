const Campaigns = () => {
  return "For the List of campaigns";
};

export default Campaigns;
