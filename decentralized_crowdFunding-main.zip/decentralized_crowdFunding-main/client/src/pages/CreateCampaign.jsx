const CreateCampaign = () => {
  return "To create New Campaign";
};

export default CreateCampaign;
